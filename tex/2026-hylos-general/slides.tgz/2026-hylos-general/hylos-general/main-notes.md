# Speaker notes

## This Talk (p. 2)

- Theme: spec in, fast program out, every step an equation
- 1: the classic theory, with code; laws for parallelism
- 2: making it machine-checked, with runnable code
- 3: where we are going

## Rewrite Rules You Already Trust (p. 4-6)

- SQL: predicate pushdown, a law of relational algebra
- PyTorch / XLA: element-wise ops fused into one kernel
- Click: should you trust them? PyTorch #196468 (open, high priority): the fusion ignores which axis softmax uses; a side condition nobody checks
- Click: trust needs proved laws and checked side conditions; for our own programs: the algebra of programming

## Programs as Algebra (p. 7-8)

- Yes: the algebra of programming (program calculation)
- Backus: programs you can do algebra on
- Bird and Meertens: a notation and laws for lists (Squiggol)
- Malcolm; Meijer et al.: the same laws for every data type
- Bird and de Moor: the book; Hinze et al.: one scheme (hylos)
- Gibbons: the patterns, in a book (CUP, Feb 2027)
- Click: Backus's abstract (1977 Turing lecture)

## A Specification and a Program (p. 9-10)

- Top: obviously right, but a temporary list
- Bottom: what we want to run
- Not tested equal: derived by a law, proved once

## The Law Behind It (p. 11-12)

- fold = reduce: an accumulator loop
- sum, count, max: same loop, different step
- Fusion: why the two programs are equal
- Uniqueness: the universal property, proof engine of the theory

## Divide and Conquer (p. 13-18)

- Quicksort, written directly
- Click: divide (pivot, split the rest); recursion; conquer (glue)
- Click: factor them out; one generic function
- Last click: tag = the case divide found (None: empty list; p: non-empty) and the data conquer needs (the pivot); conquer dispatches on it
- The pattern: a hylomorphism (divide: coalgebra, conquer: algebra)

## The Pattern, in Haskell (p. 19-20)

- From here on: Haskell; explain the syntax as needed
- Layer: one layer of the call tree
- f . g: g then f; fmap h: h on every part
- hylo = conquer . fmap hylo . divide: the equation Rocq proves things about

## The Call Tree of Quicksort (p. 21-23)

- Everyone knows this tree; the point is its type
- Nodes are layers: Leaf, or Node with a pivot; grey: what divide got
- Layer: as in qsort; x marks where the parts go
- Least fixed point: smallest solution of Tree = Layer Tree, finite trees
- Haskell is lazy (also infinite trees); Rocq: finite only, so divide must terminate (Part II)
- Build, then fold = hylo, with no tree (deforestation, soon)
- Independent subtrees: parallelism comes back later

## Where Hylomorphisms Come From (p. 24)

- F: one layer (Layer in the Haskell); divide: coalgebra, conquer: algebra
- Hagino: data types as initial algebras, final coalgebras
- Name: Meijer et al. 1991 (Greek matter + form: unfold, then fold)
- Hu et al.: the HYLO system finds hylos in ordinary code
- Unique h: recursive coalgebras (CUV); terminating (well-founded) divide suffices (AMM): key for Rocq later

## Why Hylomorphisms Matter (p. 25)

- General: conjugate hylomorphisms
- Laws: deforestation (Wadler), shortcut fusion (in GHC); HYLO system
- Parallel: subtrees independent (later)

## Fusion and Deforestation (p. 26-27)

- Fusion: post-processing moves into conquer, pre-processing into divide (either may be the identity)
- Deforestation: ana builds the tree, cata folds it; together, no tree
- Uniqueness again; it needs care, back in Part II

## Calculating Sort-Then-Double (p. 28-29)

- Spec: sort, then double
- Side condition: doubling distributes over concatenation
- Result: the program you would write by hand
- We will redo this in Rocq, and run it

## List Homomorphisms (p. 30-32)

- Split anywhere, solve the pieces, combine
- sum, max, sort all qualify; first theorem (Bird): map then reduce
- Scheduling: the runtime picks the split for speed; correctness is settled once

## Where Does the Combiner Come From? (p. 33-34)

- Digits to a number: the obvious loop
- Parallel streams: you must supply the combiner
- A wrong combiner: wrong answers, only in parallel
- val alone is not enough: needs scale; same in Spark, OpenMP

## The Third Homomorphism Theorem (p. 35-39)

- Precisely: h = foldl stepL e = foldr stepR e; loop steps take one element, need not be associative
- Left loop: h (xs ++ ys) = foldl stepL (h xs) ys; right loop: foldr stepR (h ys) xs
- So h xs = h xs', h ys = h ys' give equal results: a combiner exists
- Compute it: combine a b = h (g a ++ g b), g a: any list with result a (no circularity)
- Bird conjectured, Meertens proved it on a train; Gibbons published

## Homomorphisms Are Divide and Conquer (p. 40)

- A homomorphism is a hylo whose divide step is a parameter
- splitBy: the leaves, and any cut that keeps the order
- halves: balanced, depth log n, parallel; heads: a loop
- Same answer for every cut: pick the cut for the machine

## Same Combiner, Another Cut (p. 41-42)

- Left: heads, depth n; right: halves, depth log n
- Associativity of the combiner makes them equal
- foldl, foldr: hylos with a fixed cut and a non-associative step
- Third theorem: a proof that the two loops agree yields the parallel program (associative combine, any cut), by calculation
- Remember: changing the divide step comes back at the end

## Extensions (p. 43)

- From pen-and-paper theorems to tools
- Extra state = lifting, as in the Java example (tupling)
- Morita et al.: derive g by program inversion
- Farzan and Nicolet: program synthesis for loops; back in Part III

## One Specification, Many Parallel Programs (p. 44-45)

- Skeletons: reusable parallel patterns; fb = feedback, farm = replicated workers, || = pipeline
- Split stage: an unfold as a loop; merge stage: a fold as a loop
- Same result as mergesort, many choices of n and k
- Two questions: is it equal? which is fastest?

## Another Structure, Same Specification (p. 46-47)

- Same specification, msort; another parallel structure
- Farms inside the feedback loops: many splitters, many mergers
- Short lists leave the splitters sorted: pipeline law, fun f || fun g = fun (g . f)
- Any pairing of merges is fine: associative and commutative
- Which is faster depends on the machine: next, the cost model

## Skeletons Mean Hylomorphisms (p. 48-50)

- Each skeleton has a sequential meaning: a farm computes its worker; dc is a hylomorphism
- The structure goes in the type; the program stays sequential
- Type checking decides equivalence, using the laws

## Reforestation, Then Choose by Cost (p. 51-53)

- Reforestation: deforestation backwards, put the tree back to expose stages
- Type checking: erase the parallelism, normalise, unify with the type
- Commutative merge: the feedback stage needs no order
- Cost model: chunk size and workers; scheduling again

## What Was Missing (p. 54-57)

- ICFP'16: soundness on paper, laws taken for granted; cpo semantics
- Same elsewhere: compilers (HYLO), transformation systems (MAG, HERMIT), point-free tools (Cunha et al.), skeleton libraries (SkeTo)
- Higher-order code (folds, combinators, skeletons): efficiency left to the compiler's inliner and code generator, both trusted
- Next: can a proof assistant do this?

## Program Calculation in Proof Assistants (p. 59)

- Agda AoPA: relational derivations, no extraction
- Tesson et al., SyDPaCC: list homomorphisms in Coq/Rocq, parallel OCaml (BSML)
- Murata and Emoto: schemes, but funext and no hylos; Braga: per algorithm
- Abreu et al.: termination by typing; funext, impredicative Set; casts

## The Gap (p. 60-65)

- Generic: any polynomial shape, divide and conquer
- Laws as regular equalities: rewrite with them, as on paper
- No axioms: results hold in plain Rocq
- Clean code: what you would write by hand, no casts
- Each earlier work misses at least one

## Why Not Just Write `hylo`? (p. 66-67)

- Rocq: programs must terminate (the logic stays consistent)
- The recursive call is on divide x, not on a piece of x: rejected
- Quicksort, mergesort: rejected for the same reason
- Program Fixpoint, Equations: a proof per function, no fusion laws

## Three Obstacles (p. 68-69)

- Termination: h = h + 1 has no solution, h = h has every one; need recursive coalgebras
- Axioms: funext, axiom K; we want none
- Clean code: what you would write by hand, no Obj.magic
- Theme of this part: proofs vs code

## Generic Trees: The Textbook Encoding (p. 70-72)

- Container: shapes, and positions per shape (Abbott, Altenkirch, Ghani)
- Positions depend on the shape: a type family
- Extraction: every shape and position through Obj.magic (real output)
- Equality: injection gives equal dependent pairs; k1 = k2 needs inj_pair2, i.e. axiom K; fmap id = id needs funext

## Our Generic Trees (p. 73)

- One type P of positions, a boolean says which are valid
- Valid: a proof of b = true; unique without axiom K (Hedberg); erased
- Extraction sees cont as a plain function P -> X
- Setoids: every type has =e, functions respect it (A > B)

## Termination: Recursion on a Proof (p. 74-76)

- RecF c x: c terminates on x; a proof is a finite tree shaped like the call tree
- Recursive coalgebra: RecF for every input; proved once per coalgebra (e.g. pieces are shorter)
- hylo: structural recursion on the proof; proof erased
- RecF iff Acc, but per-position induction: easier proofs, same code

## The Laws, Proved Once (p. 77-78)

- Uniqueness is the universal property; the rest follow
- Same steps as on paper
- Print Assumptions: nothing

## Proofs or Code? Every Definition Is a Choice (p. 79)

- Top: choices made for both proofs and code
- Same-results equality = setoids: no funext, but every function needs a properness proof; rewriting slow
- RecF vs Acc: proofs only
- Bottom three: easy proofs, costly code; ITP output shows it; fixed later

## Generic Code Is Not (Always) Clean Code (p. 80-82)

- Not always: this is our generic hylo with Rocq's extraction, not generic code in general
- Type-safe, but setoid and container dictionaries passed at run time
- A record built and taken apart at every call
- ITP: inline by hand-picked hints; still closures (next)

## What ITP 2025 Extracted (p. 83-84)

- Real output of the paper's version (Rocq 9 port)
- x0: the children as a function, a closure each call
- Good, but not what you would write

## The Price of Our Choices (p. 85-88)

- Cons of the ITP 2025 design (paper, future work)
- Setoids: properness proofs, slow generalised rewriting, big terms
- Termination: once per coalgebra, but still there
- Inlining: Rocq does not always inline; closures left (previous slide)
- Acid rain needs parametricity: only for lists

## Since ITP 2025 (p. 89-93)

- Rocq 9 port, then October 2026
- Derive, arewrite, finished: calculations as on paper
- Instance search: no hand-written properness or termination proofs
- hylo_cps_hylo, reenumerate, dyna_loop, dyna_iso
- Monoid algebras: list homomorphisms for any shape

## Demo (p. 94)

- Optional; open demo/Demo.v in VS Code (VsRocq)
- Step through the Derive; show goals
- Remove the Fail: "no subterm matching" hylo after hylo
- After the demo: skip the slides marked "covered by the demo"

## A Calculation in Rocq (p. 95-97)

- `Derive`: the program starts as an unknown
- The spec: quicksort, then double (Part I)
- One line of laws; Rocq fills in the program

## Quicksort, Step by Step (p. 98-101)

- Each step: one law, the term Rocq shows after it
- map_merge_fusion: doubling moves inside merge
- hylo_ana, deforest: the tree between unfold and fold disappears (one step)
- hylo_cps_hylo: continuation-passing coalgebra, so the code has no closures

## Quicksort: What Comes Out (p. 102)

- Real extraction output
- Point at the pivot: `mul 2 i`
- Compare with the ITP output: no x0 closure

## Dynamic Programming: Knapsack (p. 103-105)

- Classic recurrence; items (2, 3), (3, 4), capacity 6
- Red nodes: recomputed
- Fix: a table of results (dynamorphism, Hinze, Wu, Gibbons)
- ITP 2025: the table as nested records, linear lookups; since: arrays, and derived from this exponential hylo by rewriting

## Knapsack, Step by Step (p. 106-109)

- The goal after each rewrite, as Rocq prints it
- reenumerate: from items to capacities, lookups jump into the array, O(1)
- dyna_loop: the table is built by a loop counting up
- Last line: a loop over the capacities, one step each

## Knapsack: What Comes Out (p. 110)

- Simplified from the extracted code (real one in the library)
- `knapsack`: a loop counting capacities up; `push` adds one entry
- `fast_drop`: jump into the array
- Every step proved

## Associative Combiners, for Any Data Type (p. 111-112)

- malg = monoid algebra: combine a node's value with its children's results, in order
- malg_fusion: any monoid homomorphism fuses, one-line proof
- Part I's homomorphisms, generalised
- Maximum segment sum: Bird's calculation, machine-checked

## Two Ways Out of Rocq (p. 114-115)

- Box = verified in Rocq
- Today: exit through OCaml (GC, closures, boxed integers)
- Goal: more laws down to a low-level form, printed directly
- Layout and scheduling become calculation steps
- Two lines of work show what such laws look like

## Trees Without Pointers (p. 116-117)

- Michael Vollmer's line of work (Gibbon compiler)
- Pointer trees: allocation, poor locality
- Serialised: one buffer, read in order
- LoCal: locations as types; ICFP'21: parallelism on dense data
- Marmoset: a cost model picks the field order

## A Traversal over a Buffer (p. 118-119)

- Same function, on the buffer (hand-written sketch, not Gibbon's output)
- Left child: right after the tag
- Right child: only known after the left is traversed (end witnesses, LoCal)
- Order of traversal = order of layout

## Packed Traversals, Read as Hylomorphisms (p. 120-122)

- Our reading, not Gibbon's formulation
- Spec: unpack the buffer, fold the tree
- Program: traverse the buffer; the tree never exists
- Writes: an associative combiner (Part II)
- Cursor threading: state between siblings; laws beyond plain hylos

## Nested Loops, Divided and Conquered (p. 123-125)

- Read-only multidimensional data; a loop nest computes a function
- Summarise the inner loop, then parallelise the outer one
- Sound and complete: nothing lost by going modular
- ParSynt: joins by SyGuS; checked in Rosette (bounded), most also in Dafny
- About 9-13x on 16 threads

## The Same Story, with Hylomorphisms (p. 126-127)

- Each notion has a recursion-scheme reading
- Homomorphism = associative combiner (monoid algebra, Part II)
- Divide and conquer = new divide step (Part I, same combiner)
- Their theorem justifies parallelising nested hylos level by level
- In Rocq: a law, proved once; no per-program bounded check

## Why a Mechanised Framework? (p. 128-129)

- ICFP'16: laws assumed
- Gibbon: correct by careful engineering, unverified
- ParSynt: theorems on paper; each join checked; loop translation not verified
- Ours: laws are Rocq theorems; derivation is a certificate
- Without clean extraction, this is only a proof about a model

## Laws That Change Representation (p. 130-133)

- Tree to buffer: what Gibbon does, as a law
- Recursion to loop: dyna_loop already does this for knapsack
- Independent pieces: Farzan and Nicolet, as a law
- All proved once, used as rewrites

## Untrusted Search, Trusted Checking (p. 134-135)

- Search: heuristics, e-graphs, or an ML model
- Rocq checks the chain of laws; wrong proposals rejected
- Everything clever so far is search: keep it, check its answer

## Where We Are (p. 136)

- Early stage; be honest
- Done: exact-cover splits, machine integers, buffers, tree reductions, writes; materialising into a buffer defined, no laws yet
- Not yet: buffer laws, exactly-once, nesting, target, cost model

## Summary (p. 137)

One line per part

## (no title) (p. 138)

Questions

